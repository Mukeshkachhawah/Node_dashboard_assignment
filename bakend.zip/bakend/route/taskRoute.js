const express = require("express");
const taskController = require("../controller/taskContoller");
const router = express.Router();

router.post("/create", taskController.createTask);
router.post("/complete", taskController.completeTask);

module.exports = router;
