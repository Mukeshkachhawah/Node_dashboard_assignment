const TastkModel = require("../model/taskModel");

exports.createTask = async (req, res) => {
  const { name, listId } = req.body;
  try {
    const task = await TastkModel.create({ name, ListId: listId });
    res.status(201).json(task);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.completeTask = async (req, res) => {
  const { taskId } = req.body;
  try {
    const task = await TastkModel.findByPk(taskId);
    task.completed = true;
    await task.save();
    res.json(task);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
