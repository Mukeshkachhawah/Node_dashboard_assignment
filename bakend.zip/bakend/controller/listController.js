const ListController = require("../model/listModel");

exports.createList = async (req, res) => {
  const { name, userId } = req.body;
  try {
    const list = await ListController.create({ name, user: userId });
    res.status(201).json(list);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.moveTask = async (req, res) => {
  const { taskId, listId } = req.body;
  try {
    const task = await ListController.findByPk(taskId);
    task.ListId = listId;
    await task.save();
    res.json(task);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
